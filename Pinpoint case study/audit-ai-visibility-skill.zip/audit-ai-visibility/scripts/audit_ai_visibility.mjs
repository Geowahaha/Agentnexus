#!/usr/bin/env node

const args = process.argv.slice(2);
const format = args.includes("--markdown") || args.includes("--md") ? "markdown" : "json";
const input = args.find((arg) => !arg.startsWith("--"));

if (!input) {
  console.error("Usage: node audit_ai_visibility.mjs https://example.com [--markdown]");
  process.exit(1);
}

const base = normalizeBase(input);
const host = new URL(base).hostname;
const wwwBase = host.startsWith("www.")
  ? base
  : `${new URL(base).protocol}//www.${host}`;

const botAgents = [
  "GPTBot",
  "ClaudeBot",
  "Google-Extended",
  "OAI-SearchBot",
  "ChatGPT-User",
  "PerplexityBot",
];

function normalizeBase(value) {
  const withProtocol = /^https?:\/\//i.test(value) ? value : `https://${value}`;
  const url = new URL(withProtocol);
  url.pathname = "/";
  url.search = "";
  url.hash = "";
  return url.toString().replace(/\/$/, "");
}

function cacheBust(url) {
  const u = new URL(url);
  u.searchParams.set("codex_audit", String(Date.now()));
  return u.toString();
}

async function fetchText(url, options = {}) {
  const started = Date.now();
  try {
    const response = await fetch(cacheBust(url), {
      redirect: options.redirect ?? "follow",
      headers: {
        "Cache-Control": "no-cache",
        Pragma: "no-cache",
        ...(options.headers ?? {}),
      },
    });
    const text = await response.text();
    return {
      ok: true,
      url,
      finalUrl: response.url,
      status: response.status,
      ms: Date.now() - started,
      headers: Object.fromEntries(response.headers.entries()),
      text,
    };
  } catch (error) {
    return {
      ok: false,
      url,
      status: "ERR",
      ms: Date.now() - started,
      error: error?.message ?? String(error),
      headers: {},
      text: "",
    };
  }
}

function countMarkdownLinks(text) {
  return (text.match(/\[[^\]]+\]\(https?:\/\/[^\)]+\)/g) ?? []).length;
}

function countBareUrls(text) {
  return (text.match(/https?:\/\/\S+/g) ?? []).length;
}

function hasH1(text) {
  return /^#\s+\S/m.test(text);
}

function contentSignal(headers) {
  return headers["content-signal"] ?? "";
}

function titleOf(html) {
  const match = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return match ? match[1].replace(/\s+/g, " ").trim() : "";
}

function canonicalOf(html) {
  const match = html.match(/<link[^>]+rel=["']canonical["'][^>]*>|<link[^>]+href=["'][^"']+["'][^>]+rel=["']canonical["'][^>]*>/i);
  return match ? match[0] : "";
}

const root = await fetchText(`${base}/`);
const robots = await fetchText(`${base}/robots.txt`);
const llms = await fetchText(`${base}/llms.txt`);
const ai = await fetchText(`${base}/ai.txt`);
const agents = await fetchText(`${base}/agents.txt`);
const sitemap = await fetchText(`${base}/sitemap.xml`);
const www = await fetchText(`${wwwBase}/`, { redirect: "follow" });

const botChecks = [];
for (const agent of botAgents) {
  const result = await fetchText(`${base}/`, {
    headers: { "User-Agent": agent },
  });
  botChecks.push({
    userAgent: agent,
    status: result.status,
    contentSignal: contentSignal(result.headers),
    title: titleOf(result.text),
  });
}

const html = root.text;
const gtagScriptCount = (html.match(/googletagmanager\.com\/gtag\/js/gi) ?? []).length;
const trackingLoader = /tracking(?:\.min)?\.js/i.test(html);

const report = {
  checkedAt: new Date().toISOString(),
  base,
  endpoints: {
    root: summarize(root),
    robots: summarize(robots),
    llms: summarize(llms),
    ai: summarize(ai),
    agents: summarize(agents),
    sitemap: summarize(sitemap),
    www: summarize(www),
  },
  robotsPolicy: {
    hasAiInputNo: /ai-input=no/i.test(robots.text),
    hasAiInputYes: /ai-input=yes/i.test(robots.text),
    importantAgentsPresent: Object.fromEntries(
      botAgents.map((agent) => [agent, new RegExp(`User-agent:\\s*${escapeRegex(agent)}`, "i").test(robots.text)])
    ),
  },
  llms: {
    hasH1: hasH1(llms.text),
    markdownLinkCount: countMarkdownLinks(llms.text),
    bareUrlCount: countBareUrls(llms.text),
    hasAiInputNo: /ai-input=no/i.test(llms.text),
    hasAiInputYes: /ai-input=yes/i.test(llms.text),
  },
  homepage: {
    title: titleOf(html),
    canonical: canonicalOf(html),
    hasGA4Id: /G-[A-Z0-9]+/.test(html),
    gtagScriptCount,
    trackingLoader,
    hasWebMcpHints: /toolname=|tooldescription=|toolparamdescription=/i.test(html),
    hasAiInputNo: /ai-input=no/i.test(html),
  },
  botChecks,
  likelyIssues: inferIssues({ root, robots, llms, www, botChecks, html }),
};

if (format === "markdown") {
  console.log(toMarkdown(report));
} else {
  console.log(JSON.stringify(report, null, 2));
}

function summarize(result) {
  return {
    status: result.status,
    finalUrl: result.finalUrl ?? "",
    contentType: result.headers["content-type"] ?? "",
    contentSignal: contentSignal(result.headers),
    ms: result.ms,
    error: result.error ?? "",
  };
}

function inferIssues({ root, robots, llms, www, botChecks, html }) {
  const issues = [];
  if (root.status !== 200) issues.push("Root page is not HTTP 200.");
  if (robots.status !== 200) issues.push("robots.txt is not HTTP 200.");
  if (/ai-input=no/i.test(robots.text)) issues.push("robots.txt still contains ai-input=no.");
  if (llms.status !== 200) issues.push("llms.txt is not HTTP 200.");
  if (!hasH1(llms.text)) issues.push("llms.txt lacks a Markdown H1.");
  if (countMarkdownLinks(llms.text) === 0) issues.push("llms.txt has no Markdown links.");
  if (String(www.status) === "522") issues.push("www host returns Cloudflare 522.");
  for (const check of botChecks) {
    if (check.status !== 200) issues.push(`${check.userAgent} returned ${check.status}.`);
  }
  if (/ai-input=no/i.test(html)) issues.push("Homepage HTML contains ai-input=no.");
  if (!/G-[A-Z0-9]+/.test(html)) issues.push("No GA4-style measurement ID found in homepage HTML.");
  return issues;
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function toMarkdown(data) {
  const lines = [];
  lines.push(`# AI Visibility Audit: ${data.base}`);
  lines.push("");
  lines.push(`Checked at: ${data.checkedAt}`);
  lines.push("");
  lines.push("## Endpoint Health");
  for (const [name, endpoint] of Object.entries(data.endpoints)) {
    lines.push(`- ${name}: ${endpoint.status} -> ${endpoint.finalUrl || "(no final URL)"}`);
  }
  lines.push("");
  lines.push("## AI Policy");
  lines.push(`- robots has ai-input=no: ${data.robotsPolicy.hasAiInputNo}`);
  lines.push(`- robots has ai-input=yes: ${data.robotsPolicy.hasAiInputYes}`);
  lines.push(`- llms H1: ${data.llms.hasH1}`);
  lines.push(`- llms Markdown links: ${data.llms.markdownLinkCount}`);
  lines.push(`- llms bare URLs: ${data.llms.bareUrlCount}`);
  lines.push(`- llms has ai-input=no: ${data.llms.hasAiInputNo}`);
  lines.push("");
  lines.push("## Bot Access");
  for (const bot of data.botChecks) {
    lines.push(`- ${bot.userAgent}: ${bot.status} (${bot.contentSignal || "no content-signal"})`);
  }
  lines.push("");
  lines.push("## Homepage");
  lines.push(`- title: ${data.homepage.title || "(none)"}`);
  lines.push(`- canonical: ${data.homepage.canonical || "(none)"}`);
  lines.push(`- GA4-like ID present: ${data.homepage.hasGA4Id}`);
  lines.push(`- gtag script count: ${data.homepage.gtagScriptCount}`);
  lines.push(`- tracking loader present: ${data.homepage.trackingLoader}`);
  lines.push(`- WebMCP hints present: ${data.homepage.hasWebMcpHints}`);
  lines.push("");
  lines.push("## Likely Issues");
  if (data.likelyIssues.length === 0) {
    lines.push("- None detected by this quick audit.");
  } else {
    for (const issue of data.likelyIssues) lines.push(`- ${issue}`);
  }
  lines.push("");
  lines.push("## Next Validation");
  lines.push("- Compare GA4 source/medium and landing pages before/after changes.");
  lines.push("- Compare Search Console clicks, impressions, indexed pages, and crawl stats.");
  lines.push("- Check CDN/hosting logs for AI bot requests and host-level errors.");
  return lines.join("\n");
}
