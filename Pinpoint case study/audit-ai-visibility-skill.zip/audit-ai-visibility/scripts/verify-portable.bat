@echo off
setlocal

where node >nul 2>nul
if errorlevel 1 (
  echo FAIL: Node.js was not found on PATH.
  echo Install Node.js 18 or newer.
  exit /b 127
)

for /f "tokens=1 delims=." %%A in ('node -p "process.versions.node"') do set "NODE_MAJOR=%%A"
if %NODE_MAJOR% LSS 18 (
  echo FAIL: Node.js 18 or newer is required. Found:
  node -v
  exit /b 1
)

if not exist "%~dp0audit_ai_visibility.mjs" (
  echo FAIL: Missing scripts\audit_ai_visibility.mjs
  exit /b 1
)

if not exist "%~dp0audit-ai-visibility.bat" (
  echo FAIL: Missing scripts\audit-ai-visibility.bat
  exit /b 1
)

echo OK: Portable runtime check passed.
node -v
exit /b 0
