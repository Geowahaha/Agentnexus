#!/usr/bin/env sh
set -eu

if ! command -v node >/dev/null 2>&1; then
  echo "Error: Node.js was not found on PATH." >&2
  echo "Install Node.js 18 or newer, then run this command again." >&2
  exit 127
fi

if [ "$#" -lt 1 ]; then
  echo "Usage: $(basename "$0") https://example.com [--markdown]" >&2
  echo "Example JSON: $(basename "$0") https://example.com" >&2
  echo "Example Markdown: $(basename "$0") https://example.com --markdown" >&2
  exit 2
fi

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
node "$SCRIPT_DIR/audit_ai_visibility.mjs" "$@"
