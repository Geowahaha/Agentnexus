@echo off
setlocal

where node >nul 2>nul
if errorlevel 1 (
  echo Error: Node.js was not found on PATH.
  echo Install Node.js 18 or newer, then run this command again.
  exit /b 127
)

if "%~1"=="" (
  echo Usage: %~nx0 https://example.com [--markdown]
  echo Example JSON: %~nx0 https://example.com
  echo Example Markdown: %~nx0 https://example.com --markdown
  exit /b 2
)

set "SCRIPT_DIR=%~dp0"
node "%SCRIPT_DIR%audit_ai_visibility.mjs" %*
exit /b %ERRORLEVEL%
